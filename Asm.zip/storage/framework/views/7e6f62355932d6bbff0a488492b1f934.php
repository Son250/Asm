
<?php $__env->startSection('content'); ?>
    <main class="main">
        <div class="container">
            
            <div align="center" class="m-5">
                <h3>GIỎ HÀNG</h3>
            </div>
            <?php if(session('status')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('status')); ?>

                </div>
            <?php endif; ?>
            <?php if(Session::has('user')): ?>

                <div class="row">
                    <div class="col-lg-8">
                        <form action="<?php echo e(route('updateCart')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <div class="cart-table-container">
                                <table class="table table-cart">
                                    <thead>
                                        <tr>
                                            <th></th>
                                            <th class="thumbnail-col">Ảnh</th>
                                            <th class="product-col">Tên sản phẩm</th>
                                            <th class="price-col">Giá</th>
                                            <th class="qty-col">Số lượng</th>
                                            <th class="text-right">Tổng giá</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php if(count($carts) > 0): ?>
                                            <?php $__currentLoopData = $carts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr class="product-row">
                                                    <td>
                                                        <a href="<?php echo e(route('deleteCart', $item->idCart)); ?>">Xóa</a>
                                                    </td>
                                                    <td>
                                                        <figure class="product-image-container">
                                                            <a href="product.html" class="product-image">
                                                                <img width="80"
                                                                    src="<?php echo e(asset('images/' . $item->img)); ?>"
                                                                    alt="product">
                                                            </a>
                                                        </figure>
                                                    </td>
                                                    <td class="product-col">
                                                        <h5 class="product-title">
                                                            <a href="#" class="text-muted"><?php echo e($item->name); ?></a>
                                                        </h5>
                                                    </td>
                                                    <td><?php echo e(number_format($item->price, '0', ',', '.')); ?>đ</td>
                                                    <td>
                                                        <div class="product-single-qty">
                                                            <input class="horizontal-quantity form-control" type="text"
                                                                name="quantity" value="<?php echo e($item->quantityProductCart); ?>">
                                                        </div><!-- End .product-single-qty -->
                                                    </td>
                                                    <td class="text-right"><span
                                                            class="subtotal-price"><?php
                                                                $total = $item->price * $item->quantityProductCart;
                                                                echo number_format($total, '0', ',', '.');
                                                            ?></span>đ
                                                    </td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php else: ?>
                                            <tr class="product-row">
                                                <td colspan="6" align="center">Giỏ hàng của bạn trống</td>
                                            </tr>
                                        <?php endif; ?>
                                    </tbody>


                                    <tfoot>
                                        <tr>
                                            <td colspan="6" class="clearfix">
                                                <div class="float-left">
                                                    <div class="cart-discount">
                                                        
                                                        <p>Nếu bạn thay đổi số lượng vui lòng bấm Cập nhật giỏ hàng để cập
                                                            nhật số lượng và giá cho bạn</p>
                                                    </div>
                                                </div><!-- End .float-left -->


                                                <div class="float-right">

                                                    <button type="submit" class="btn btn-shop btn-update-cart">
                                                        Cập nhật giỏ
                                                    </button>
                                                </div><!-- End .float-right -->
                                            </td>
                                        </tr>
                                    </tfoot>
                                </table>
                            </div><!-- End .cart-table-container -->
                        </form>
                    </div><!-- End .col-lg-8 -->

                    <div class="col-lg-4">
                        <div class="cart-summary border p-5">
                            <h4>CART TOTALS</h4>

                            <table class="table table-totals">
                                <tbody>
                                    <tr>
                                        <td>Tổng tiền:</td>
                                        <td><?php echo e(number_format($totalPrice, '0', ',', '.')); ?>đ</td>
                                    </tr>

                                    <tr>
                                        
                                    </tr>
                                </tbody>

                                <tfoot>
                                    
                                </tfoot>
                            </table><br>
                            <?php if(count($carts) > 0): ?>
                                <div class="checkout-methods">
                                    <a href="<?php echo e(route('checkout')); ?>" class="btn btn-block btn-dark">Tiến hành thanh toán
                                        <i class="fa fa-arrow-right"></i></a>
                                </div>
                            <?php endif; ?>
                        </div><!-- End .cart-summary -->
                    </div><!-- End .col-lg-4 -->
                </div><!-- End .row -->
            <?php else: ?>
                <p>Bạn cần đăng nhập để sử dụng giỏ hàng</p>
            <?php endif; ?>
        </div><!-- End .container -->

        <div class="mb-6"></div><!-- margin -->
    </main><!-- End .main -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.client', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laragon\www\Asm\resources\views/client/cart.blade.php ENDPATH**/ ?>
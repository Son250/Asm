
<?php $__env->startSection('content'); ?>
    <!-- Begin Page Content -->
    <div class="container-fluid">

        <!-- Page Heading -->
        <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800">Thay đổi trạng thái </h1>

        </div>
        <div class="card shadow mb-4">
            <div class="card-body">

                <form action="<?php echo e(route('updateOrder', $order->id)); ?>" method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php if(session('error')): ?>
                        <div class="alert alert-danger">
                            <?php echo e(session('error')); ?>

                        </div>
                    <?php endif; ?>
                    <p><strong>Mã đơn hàng:</strong> <?php echo e($order->id); ?></p>
                    <p><strong>Khách hàng :</strong> <?php echo e($order->shipping_address); ?></p>
                    <p><strong>Phương thức thanh toán :</strong> <?php echo e($order->payment_method); ?></p>
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label for="" class="text-primary"><b>Trạng thái:</b> </label> <br>
                            <select name="status" id="" class="form-control">
                                <?php $__currentLoopData = $status_order; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($loop->iteration); ?>"
                                        <?php if($item == $order->status): ?> selected <?php endif; ?>><?php echo e($item); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="text-danger"><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <ul>
                        <?php $__currentLoopData = $order->orderItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li>
                                <p><strong>Sản phẩm:</strong> <?php echo e($item->product->name); ?></p>
                                <p><strong>Số lượng:</strong> <?php echo e($item->quantity); ?></p>
                                <p><strong>Giá:</strong> <?php echo e(number_format($item->price, 0, ',', '.')); ?>đ</p>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                    <p><strong>Ngày đặt:</strong> <?php echo e($order->order_date); ?></p>
                    <p><strong>Tổng tiền:</strong> <?php echo e(number_format($order->total_amount, 0, ',', '.')); ?>đ</p>


                    <button class="btn btn-success" type="submit" name="btnSubmit">Gửi</button>
                </form>
            </div>
        </div>


    </div>
    <!-- /.container-fluid -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laragon\www\Asm\resources\views/admin/order/edit.blade.php ENDPATH**/ ?>
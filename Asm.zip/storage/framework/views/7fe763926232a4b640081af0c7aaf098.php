
<?php $__env->startSection('content'); ?>
    <style>
        .description-cell small {
            display: -webkit-box;
            -webkit-line-clamp: 3;
            -webkit-box-orient: vertical;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: normal;
        }
    </style>

    <!-- Begin Page Content -->
    <div class="container-fluid">
        <h1 class="h3 pl-3 text-gray-800 mb-3">Danh sách đơn hàng</h1>
        <?php if(session('status')): ?>
            <div class="alert alert-warning">
                <?php echo e(session('status')); ?>

            </div>
        <?php endif; ?>
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <button class="btn btn-secondary btn-sm">Chọn tất cả</button>
                <button class="btn btn-secondary btn-sm">Bỏ chọn tất cả</button>
                <button class="btn btn-secondary btn-sm">Xóa các mục đã chọn</button>
                
                <form action="" class="float-right">
                    <div class="input-group">
                        <input type="text" class="form-control" name="kyw" placeholder="Tìm kiếm...">
                        <div class="input-group-append">
                            <button class="btn btn-primary" type="submit" name="search">
                                <i class="fas fa-search fa-sm"></i>
                            </button>
                        </div>
                    </div>
                </form>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered" width="100%" cellspacing="0">
                        <thead class="thead-light">
                            <tr>
                                <th>STT</th>
                                <th>Tên khách hàng</th>
                                <th>Số lượng</th>
                                <th>Tổng giá</th>
                                <th>Ngày đặt</th>
                                <th>Trạng thái</th>
                                <th>Thao tác</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($i + 1); ?></td>
                                    <td width='150px'><?php echo e($item->shipping_address); ?></td>
                                    <td>
                                        <?php echo e($item->product_quantity); ?>

                                    </td>
                                    <td><?php echo e(number_format($item->total_amount, 0, ',', '.')); ?>đ</td>
                                    <td><?php echo e($item->order_date); ?> </td>
                                    <td><?php echo e($item->status); ?></td>
                                    <td>
                                        <a class="btn btn-warning" target="_blank" href="<?php echo e(route('showOrder', $item->id)); ?>">Xem hóa
                                            đơn</a>
                                        <a class="btn btn-primary" href="<?php echo e(route('editOrder', $item->id)); ?>">Sửa</a>
                                        <a class="btn btn-danger"
                                            onclick="return confirm('Bạn chắc chắn muốn xóa không?')"
                                            href="<?php echo e(route('deleteOrder', $item->id)); ?>">Hủy</a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="pl-3">
                <?php echo e($orders->links()); ?>

            </div>

        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laragon\www\Asm\resources\views/admin/order/list.blade.php ENDPATH**/ ?>